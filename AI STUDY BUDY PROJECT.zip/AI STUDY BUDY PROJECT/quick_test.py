# quick_test.py
from app import generate_explanation, summarize_notes, generate_quiz, generate_roadmap

print("=" * 50)
print("TESTING ALL FUNCTIONS")
print("=" * 50)

# Test explanation
print("\n📌 Testing Explanation...")
result = generate_explanation("Python programming")
print(f"Result: {result[:100]}...")

# Test summarization
print("\n📌 Testing Summarization...")
notes = "Python is a programming language. It is used for web development, data science, and automation. It has simple syntax and is easy to learn."
result = summarize_notes(notes)
print(f"Result: {result[:100]}...")

# Test quiz
print("\n📌 Testing Quiz...")
result = generate_quiz("Python")
print(f"Generated {len(result)} questions")

# Test roadmap
print("\n📌 Testing Roadmap...")
result = generate_roadmap("Python")
print(f"Roadmap keys: {result.keys()}")

print("\n" + "=" * 50)
print("✅ All tests passed!")