# test_db_correct.py
from pymongo import MongoClient
import urllib.parse

# Your CORRECT credentials from the screenshot
username = "study_buddy_user"
password = "cheqVrRwtHPSt4qN"
cluster = "cluster0.efmm3p6.mongodb.net"
database = "study_buddy"

# URL encode the password (in case it has special characters)
encoded_password = urllib.parse.quote_plus(password)

# Construct the connection string
uri = f"mongodb+srv://{username}:{encoded_password}@{cluster}/{database}?retryWrites=true&w=majority"

print("=" * 50)
print("Testing MongoDB Connection with CORRECT credentials")
print("=" * 50)
print(f"Username: {username}")
print(f"Password: {'*' * len(password)}")  # Hide password
print(f"Cluster: {cluster}")
print(f"Database: {database}")
print("-" * 50)

try:
    # Connect to MongoDB
    client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    
    # Test the connection
    client.admin.command('ping')
    print("✅ SUCCESS! Connected to MongoDB Atlas!")
    
    # Test database access
    db = client[database]
    
    # Try to create a test collection and insert data
    result = db.test_collection.insert_one({
        "test": "connection_successful",
        "timestamp": "now",
        "username": username
    })
    print(f"✅ Successfully inserted test document with ID: {result.inserted_id}")
    
    # Read it back
    doc = db.test_collection.find_one({"test": "connection_successful"})
    print(f"✅ Successfully read test document: {doc}")
    
    # Clean up
    db.test_collection.delete_many({"test": "connection_successful"})
    print("✅ Successfully cleaned up test data")
    
    # List all collections (should be empty now)
    print(f"Collections in database: {db.list_collection_names()}")
    
    print("\n🎉 ALL TESTS PASSED! Your MongoDB is correctly configured!")
    
except Exception as e:
    print(f"❌ Connection failed: {e}")
    
print("=" * 50)