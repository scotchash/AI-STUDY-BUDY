# test_api_fixed.py
import requests
import os
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

# Get your token
token = os.getenv('HUGGINGFACE_API_KEY')
print(f"Token starts with: {token[:10]}...")

# Updated headers and URL
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# New API endpoint
url = "https://router.huggingface.co/hf-inference/models/gpt2"

print(f"\nTesting connection to: {url}")
print("-" * 50)

try:
    # Test with a simple prompt
    payload = {
        "inputs": "Hello, I am an AI study assistant.",
        "parameters": {
            "max_length": 50,
            "temperature": 0.7
        }
    }
    
    print("Sending request...")
    response = requests.post(url, headers=headers, json=payload, timeout=30)
    
    print(f"Status Code: {response.status_code}")
    
    if response.status_code == 200:
        print("✅ API call successful!")
        result = response.json()
        if isinstance(result, list) and len(result) > 0:
            print(f"Response: {result[0].get('generated_text', '')[:100]}...")
        else:
            print(f"Response: {result}")
    else:
        print(f"❌ Error: {response.status_code}")
        print(f"Response: {response.text}")
        
except requests.exceptions.Timeout:
    print("❌ Request timed out")
except requests.exceptions.ConnectionError:
    print("❌ Connection error - check your internet")
except Exception as e:
    print(f"❌ Unexpected error: {e}")

print("-" * 50)