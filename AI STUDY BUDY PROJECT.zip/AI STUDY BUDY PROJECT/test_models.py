# test_models.py
import requests
import os
from dotenv import load_dotenv
import time

load_dotenv()

token = os.getenv('HUGGINGFACE_API_KEY')
headers = {"Authorization": f"Bearer {token}"}

# List of models to test
models = [
    ("gpt2", "Simple test"),
    ("microsoft/DialoGPT-medium", "For explanations"),
    ("facebook/bart-large-cnn", "For summarization"),
    ("google/flan-t5-large", "For quizzes and roadmaps"),
    ("tiiuae/falcon-7b-instruct", "Alternative for explanations"),
    ("mistralai/Mistral-7B-Instruct-v0.1", "Good all-purpose model")
]

print("=" * 60)
print("Testing Hugging Face Models with New API Endpoint")
print("=" * 60)

base_url = "https://router.huggingface.co/hf-inference/models/"

for model, purpose in models:
    print(f"\n📌 Testing {model} ({purpose})")
    print("-" * 40)
    
    try:
        url = base_url + model
        payload = {"inputs": "Hello, how are you?"}
        
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        
        if response.status_code == 200:
            print(f"✅ {model} - WORKING")
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                print(f"   Sample: {str(result[0])[:100]}...")
        elif response.status_code == 503:
            print(f"⏳ {model} - Loading (try again in a few seconds)")
            # Model might be loading, wait and retry
            time.sleep(2)
            response = requests.post(url, headers=headers, json=payload, timeout=10)
            if response.status_code == 200:
                print(f"✅ {model} - WORKING on retry")
        else:
            print(f"❌ {model} - Error {response.status_code}")
            print(f"   {response.text[:100]}")
            
    except Exception as e:
        print(f"❌ {model} - Exception: {e}")
    
    time.sleep(1)  # Small delay between requests

print("\n" + "=" * 60)