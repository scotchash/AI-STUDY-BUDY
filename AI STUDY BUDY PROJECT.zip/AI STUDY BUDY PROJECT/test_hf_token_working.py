# test_hf_token_working.py
import os
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv(override=True)

# Get your token
token = os.getenv('HUGGINGFACE_API_KEY')

print("=" * 60)
print("HUGGING FACE TOKEN TEST")
print("=" * 60)

if not token:
    print("❌ ERROR: No token found in .env file!")
    exit(1)

print(f"✅ Token loaded from .env")
print(f"Token: {token[:10]}...{token[-4:]} (length: {len(token)} chars)")
print(f"Starts with 'hf_': {token.startswith('hf_')}")

# Test the token with Hugging Face API
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# Test multiple models
models_to_test = [
    ("gpt2", "Basic text generation"),
    ("google/flan-t5-large", "Good for quizzes"),
    ("facebook/bart-large-cnn", "Good for summarization"),
]

print("\n" + "-" * 60)
print("Testing API Connection...")
print("-" * 60)

for model, description in models_to_test:
    print(f"\n📌 Testing {model} ({description})")
    
    url = f"https://router.huggingface.co/hf-inference/models/{model}"
    payload = {"inputs": "Hello, I am an AI study assistant."}
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=15)
        
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ SUCCESS! Token is working!")
            result = response.json()
            if isinstance(result, list):
                print(f"Response: {result[0].get('generated_text', '')[:100]}...")
            else:
                print(f"Response: {str(result)[:100]}...")
            break  # Exit after first success
        elif response.status_code == 401:
            print("❌ Authentication failed - token invalid")
        elif response.status_code == 503:
            print("⏳ Model is loading, try again in a moment")
        else:
            print(f"❌ Error: {response.text[:100]}")
            
    except Exception as e:
        print(f"❌ Exception: {e}")

print("\n" + "=" * 60)