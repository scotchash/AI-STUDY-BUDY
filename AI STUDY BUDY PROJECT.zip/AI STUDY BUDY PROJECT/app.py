# app.py - COMPLETE WORKING VERSION WITH ALL FEATURES
import os
import sys
import logging
import time
from datetime import datetime

# Try to fix import issues
try:
    from flask import Flask, render_template, request, flash
    from dotenv import load_dotenv
    import requests
    from pymongo import MongoClient
    from pymongo.errors import ConnectionFailure
except ImportError as e:
    print(f"Import Error: {e}")
    print("Please run: pip install -r requirements.txt")
    sys.exit(1)

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config["DEBUG"] = True
app.secret_key = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")

# MongoDB connection
try:
    mongo_uri = os.getenv('MONGODB_URI')
    if not mongo_uri:
        logger.error("MONGODB_URI not found in .env file")
        db = None
    else:
        client = MongoClient(mongo_uri)
        db = client.get_database('study_buddy')
        # Test connection
        client.admin.command('ping')
        logger.info("✅ MongoDB connection successful")
        
        # Collections
        users = db.users
        explanations = db.explanations
        summaries = db.summaries
        quizzes = db.quizzes
        roadmaps = db.roadmaps
        flashcards = db.flashcards
        
except Exception as e:
    logger.error(f"❌ MongoDB connection failed: {e}")
    db = None
    users = explanations = summaries = quizzes = roadmaps = flashcards = None

# Hugging Face API configuration
HUGGINGFACE_API_KEY = os.getenv('HUGGINGFACE_API_KEY')
if not HUGGINGFACE_API_KEY:
    logger.error("HUGGINGFACE_API_KEY not found in .env file")

HEADERS = {
    "Authorization": f"Bearer {HUGGINGFACE_API_KEY}",
    "Content-Type": "application/json"
}

MODEL_URL = "https://router.huggingface.co/hf-inference/models/facebook/bart-large-cnn"

# ==================== HELPER FUNCTIONS ====================

def call_huggingface_api(prompt, max_length=200):
    """Call Hugging Face API"""
    if not HUGGINGFACE_API_KEY:
        return None
        
    try:
        logger.info(f"Sending request...")
        
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_length": max_length,
                "min_length": 30,
                "temperature": 0.7,
                "do_sample": True
            }
        }
        
        response = requests.post(
            MODEL_URL,
            headers=HEADERS,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 503:
            logger.info("Model loading, waiting...")
            time.sleep(5)
            return call_huggingface_api(prompt, max_length)
        else:
            logger.error(f"API error: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"API call failed: {e}")
        return None

def get_text_from_response(response):
    """Extract text from the API response"""
    if not response:
        return None
    
    try:
        if isinstance(response, list) and len(response) > 0:
            if isinstance(response[0], dict):
                if 'summary_text' in response[0]:
                    return response[0]['summary_text']
                elif 'generated_text' in response[0]:
                    return response[0]['generated_text']
        elif isinstance(response, str):
            return response
    except Exception as e:
        logger.error(f"Error extracting text: {e}")
    
    return None

def generate_explanation(topic):
    """Generate concept explanation"""
    if not topic:
        return "Please provide a topic."
    
    prompt = f"Explain {topic} in simple terms for a beginner. Include key points."
    response = call_huggingface_api(prompt, max_length=300)
    text = get_text_from_response(response)
    
    if text:
        return text
    
    # Fallback
    return f"""{topic} is an interesting topic. Here are the key points:

• Start with the basics and fundamental concepts
• Practice regularly to build understanding
• Work on practical examples and projects
• Review and reinforce your learning
• Connect with others to discuss and learn

Remember: Learning {topic} is a journey. Take it step by step!"""

def summarize_notes(notes):
    """Summarize notes"""
    if not notes:
        return "Please provide notes to summarize."
    
    if len(notes) > 1000:
        notes = notes[:1000] + "..."
    
    prompt = f"Summarize these notes: {notes}"
    response = call_huggingface_api(prompt, max_length=150)
    text = get_text_from_response(response)
    
    if text:
        return text
    
    # Fallback
    words = notes.split()
    if len(words) > 30:
        return ' '.join(words[:30]) + '...'
    return notes

def generate_quiz(topic):
    """Generate interactive quiz questions"""
    if not topic:
        return []
    
    logger.info(f"Generating quiz for topic: {topic}")
    
    prompt = f"""Create 3 multiple choice questions about {topic}. 
    
For each question, follow this exact format:

Question: [Write a clear question about {topic}]
A) [First option - make it plausible]
B) [Second option - make it plausible] 
C) [Third option - make it plausible]
D) [Fourth option - make it plausible]
Correct: [A, B, C, or D]
Explanation: [Brief explanation why this answer is correct]

Make sure:
- Questions are clear and educational
- All options are relevant to {topic}
- Only one correct answer per question
- Explanations are helpful for learning

Separate each question with a blank line."""
    
    response = call_huggingface_api(prompt, max_length=800)
    text = get_text_from_response(response)
    
    questions = []
    
    if text:
        lines = text.split('\n')
        current_q = {}
        
        for line in lines:
            line = line.strip()
            if not line:
                if current_q and len(current_q) >= 5:
                    if 'question' in current_q:
                        if 'A' not in current_q:
                            current_q['A'] = 'Option A'
                        if 'B' not in current_q:
                            current_q['B'] = 'Option B'
                        if 'C' not in current_q:
                            current_q['C'] = 'Option C'
                        if 'D' not in current_q:
                            current_q['D'] = 'Option D'
                        if 'correct' not in current_q:
                            current_q['correct'] = 'A'
                        if 'explanation' not in current_q:
                            current_q['explanation'] = f'This question tests your knowledge of {topic}.'
                        questions.append(current_q)
                    current_q = {}
                continue
            
            if line.startswith('Question:'):
                if current_q:
                    if 'question' in current_q:
                        questions.append(current_q)
                current_q = {'question': line.replace('Question:', '').strip()}
            elif line.startswith('A)'):
                current_q['A'] = line[2:].strip()
            elif line.startswith('B)'):
                current_q['B'] = line[2:].strip()
            elif line.startswith('C)'):
                current_q['C'] = line[2:].strip()
            elif line.startswith('D)'):
                current_q['D'] = line[2:].strip()
            elif line.startswith('Correct:'):
                current_q['correct'] = line.replace('Correct:', '').strip()
            elif line.startswith('Explanation:'):
                current_q['explanation'] = line.replace('Explanation:', '').strip()
        
        if current_q and 'question' in current_q:
            if 'A' not in current_q:
                current_q['A'] = 'Option A'
            if 'B' not in current_q:
                current_q['B'] = 'Option B'
            if 'C' not in current_q:
                current_q['C'] = 'Option C'
            if 'D' not in current_q:
                current_q['D'] = 'Option D'
            if 'correct' not in current_q:
                current_q['correct'] = 'A'
            if 'explanation' not in current_q:
                current_q['explanation'] = f'This question tests your knowledge of {topic}.'
            questions.append(current_q)
    
    if len(questions) < 2:
        logger.info("Using default questions")
        questions = [
            {
                'question': f'What is the main characteristic of {topic}?',
                'A': 'It is a fundamental concept',
                'B': 'It is an advanced topic',
                'C': 'It is a simple idea',
                'D': 'It is a complex theory',
                'correct': 'A',
                'explanation': f'{topic} is considered a fundamental concept that forms the basis for understanding related topics.'
            },
            {
                'question': f'Why is {topic} important to learn?',
                'A': 'It has practical applications',
                'B': 'It builds theoretical knowledge',
                'C': 'Both A and B',
                'D': 'Neither A nor B',
                'correct': 'C',
                'explanation': f'Learning {topic} is important because it provides both practical applications and theoretical understanding.'
            },
            {
                'question': f'How can you best master {topic}?',
                'A': 'Practice regularly',
                'B': 'Study theory only',
                'C': 'Watch videos only',
                'D': 'Read books only',
                'correct': 'A',
                'explanation': f'Regular practice is key to mastering {topic}, combined with theoretical study and practical application.'
            }
        ]
    
    valid_questions = []
    for q in questions[:3]:
        question_data = {
            'question': q.get('question', f'Question about {topic}'),
            'A': q.get('A', 'Option A'),
            'B': q.get('B', 'Option B'),
            'C': q.get('C', 'Option C'),
            'D': q.get('D', 'Option D'),
            'correct': q.get('correct', 'A'),
            'explanation': q.get('explanation', f'This question tests your understanding of {topic}.')
        }
        valid_questions.append(question_data)
    
    logger.info(f"Generated {len(valid_questions)} questions")
    return valid_questions

def generate_roadmap(subject):
    """Generate learning roadmap"""
    if not subject:
        return {}
    
    prompt = f"""Create a learning roadmap for {subject}:

BEGINNER LEVEL:
Topics: List 3-4 fundamental topics
Explanation: What to learn at beginner level
Practice: Suggested exercises
Timeline: Estimated time

INTERMEDIATE LEVEL:
Topics: List 3-4 intermediate topics
Explanation: What to learn at intermediate level
Practice: Suggested projects
Timeline: Estimated time

ADVANCED LEVEL:
Topics: List 3-4 advanced topics
Explanation: What to learn at advanced level
Practice: Complex projects
Timeline: Estimated time"""
    
    response = call_huggingface_api(prompt, max_length=600)
    text = get_text_from_response(response)
    
    # Default roadmap
    roadmap = {
        'beginner': {
            'topics': [f'Introduction to {subject}', 'Basic concepts', 'Fundamentals', 'Core principles'],
            'explanation': f'Start with the basics of {subject}. Build a strong foundation by understanding core concepts.',
            'practice': 'Complete beginner tutorials, simple exercises, and basic projects.',
            'timeline': '2-3 weeks'
        },
        'intermediate': {
            'topics': [f'Advanced {subject}', 'Practical applications', 'Best practices', 'Tools and frameworks'],
            'explanation': f'Build on your foundation with more complex topics and real-world applications.',
            'practice': 'Work on intermediate projects, build portfolio pieces, contribute to open source.',
            'timeline': '4-6 weeks'
        },
        'advanced': {
            'topics': [f'Expert {subject}', 'Specialization', 'Research areas', 'Cutting-edge developments'],
            'explanation': f'Master advanced concepts and become an expert in specialized areas.',
            'practice': 'Build complex projects, publish research, mentor others, contribute to community.',
            'timeline': '8-12 weeks'
        }
    }
    
    return roadmap

def generate_flashcards(topic, num_cards=5):
    """Generate flashcards for a given topic"""
    if not topic:
        return []
    
    logger.info(f"Generating {num_cards} flashcards for topic: {topic}")
    
    prompt = f"""Create {num_cards} flashcards about {topic}. 
    
For each flashcard, follow this exact format:

Card 1:
Front: [Question or term about {topic}]
Back: [Answer or definition with explanation]

Card 2:
Front: [Question or term about {topic}]
Back: [Answer or definition with explanation]

Make sure:
- Each flashcard tests a different concept
- Front should be clear and concise
- Back should provide a comprehensive explanation
- Include examples where helpful
- Separate each card with a blank line"""
    
    response = call_huggingface_api(prompt, max_length=800)
    text = get_text_from_response(response)
    
    flashcards = []
    
    if text:
        lines = text.split('\n')
        current_card = {}
        
        for line in lines:
            line = line.strip()
            if not line:
                if current_card and 'front' in current_card and 'back' in current_card:
                    flashcards.append(current_card)
                    current_card = {}
                continue
            
            lower_line = line.lower()
            if 'card' in lower_line and ':' in line:
                if current_card and 'front' in current_card and 'back' in current_card:
                    flashcards.append(current_card)
                current_card = {}
            elif lower_line.startswith('front:'):
                current_card['front'] = line.replace('Front:', '').replace('front:', '').strip()
            elif lower_line.startswith('back:'):
                current_card['back'] = line.replace('Back:', '').replace('back:', '').strip()
        
        if current_card and 'front' in current_card and 'back' in current_card:
            flashcards.append(current_card)
    
    # If no flashcards were parsed, provide default flashcards
    if len(flashcards) < 2:
        flashcards = [
            {
                'front': f'What is {topic}?',
                'back': f'{topic} is a fundamental concept that forms the basis for understanding related topics. It involves key principles and applications that are essential for mastery.'
            },
            {
                'front': f'Why is {topic} important?',
                'back': f'Understanding {topic} is crucial because it provides both theoretical knowledge and practical applications. It helps in problem-solving and building advanced skills.'
            },
            {
                'front': f'What are the key components of {topic}?',
                'back': f'The key components include fundamental principles, core concepts, practical applications, and advanced techniques. Each component builds upon the previous ones.'
            },
            {
                'front': f'How can you practice {topic} effectively?',
                'back': f'Effective practice involves: 1) Regular exercises, 2) Real-world projects, 3) Peer collaboration, 4) Continuous learning, and 5) Seeking feedback from experts.'
            },
            {
                'front': f'What are common challenges when learning {topic}?',
                'back': f'Common challenges include: understanding complex concepts, maintaining motivation, finding quality resources, and applying knowledge practically. These can be overcome with consistent practice and proper guidance.'
            }
        ]
    
    return flashcards[:num_cards]

# ==================== ROUTES ====================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/explain', methods=['GET', 'POST'])
def explain():
    if request.method == 'POST':
        topic = request.form.get('topic', '').strip()
        if not topic:
            flash('Please enter a topic', 'error')
            return render_template('explain.html')
        
        try:
            explanation = generate_explanation(topic)
            logger.info(f"Generated explanation for: {topic}")
            
            if db is not None:
                explanations.insert_one({
                    'topic': topic,
                    'explanation': explanation,
                    'timestamp': datetime.utcnow()
                })
                logger.info("✅ Saved explanation to MongoDB")
            
            return render_template('explain.html', result=explanation, topic=topic)
        except Exception as e:
            logger.error(f"Error in explain route: {e}")
            flash('Error generating explanation. Please try again.', 'error')
    
    return render_template('explain.html')

@app.route('/summarize', methods=['GET', 'POST'])
def summarize():
    if request.method == 'POST':
        notes = request.form.get('notes', '').strip()
        if not notes:
            flash('Please enter notes to summarize', 'error')
            return render_template('summarize.html')
        
        try:
            summary = summarize_notes(notes)
            logger.info(f"Generated summary")
            
            if db is not None:
                summaries.insert_one({
                    'notes': notes[:200],
                    'summary': summary,
                    'timestamp': datetime.utcnow()
                })
                logger.info("✅ Saved summary to MongoDB")
            
            return render_template('summarize.html', result=summary, notes=notes[:100])
        except Exception as e:
            logger.error(f"Error in summarize route: {e}")
            flash('Error generating summary. Please try again.', 'error')
    
    return render_template('summarize.html')

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if request.method == 'POST':
        topic = request.form.get('topic', '').strip()
        if not topic:
            flash('Please enter a topic', 'error')
            return render_template('quiz.html')
        
        try:
            questions = generate_quiz(topic)
            logger.info(f"Generated {len(questions)} questions for: {topic}")
            
            if db is not None and questions:
                quizzes.insert_one({
                    'topic': topic,
                    'questions': questions,
                    'timestamp': datetime.utcnow()
                })
                logger.info("✅ Saved quiz to MongoDB")
            
            return render_template('quiz.html', questions=questions, topic=topic)
        except Exception as e:
            logger.error(f"Error in quiz route: {e}")
            flash('Error generating quiz. Please try again.', 'error')
    
    return render_template('quiz.html')

@app.route('/roadmap', methods=['GET', 'POST'])
def roadmap():
    if request.method == 'POST':
        subject = request.form.get('subject', '').strip()
        if not subject:
            flash('Please enter a subject', 'error')
            return render_template('roadmap.html')
        
        try:
            roadmap_data = generate_roadmap(subject)
            logger.info(f"Generated roadmap for: {subject}")
            
            if db is not None and roadmap_data:
                roadmaps.insert_one({
                    'subject': subject,
                    'roadmap': roadmap_data,
                    'timestamp': datetime.utcnow()
                })
                logger.info("✅ Saved roadmap to MongoDB")
            
            return render_template('roadmap.html', roadmap=roadmap_data, subject=subject)
        except Exception as e:
            logger.error(f"Error in roadmap route: {e}")
            flash('Error generating roadmap. Please try again.', 'error')
    
    return render_template('roadmap.html')

@app.route('/flashcards', methods=['GET', 'POST'])
def flashcards():
    """Flashcards Generator page"""
    if request.method == 'POST':
        topic = request.form.get('topic', '').strip()
        num_cards = request.form.get('num_cards', '5').strip()
        
        if not topic:
            flash('Please enter a topic', 'error')
            return render_template('flashcards.html')
        
        try:
            # Convert num_cards to int, default to 5
            try:
                num_cards = int(num_cards)
                if num_cards < 1:
                    num_cards = 5
                elif num_cards > 10:
                    num_cards = 10
            except ValueError:
                num_cards = 5
                logger.warning("Invalid num_cards value, using default 5")
            
            # Generate flashcards
            cards = generate_flashcards(topic, num_cards)
            logger.info(f"Generated {len(cards)} flashcards for: {topic}")
            
            # Store in MongoDB if available
            if db is not None:
                try:
                    db.flashcards.insert_one({
                        'topic': topic,
                        'num_cards': len(cards),
                        'cards': cards,
                        'timestamp': datetime.utcnow()
                    })
                    logger.info("✅ Saved flashcards to MongoDB")
                except Exception as e:
                    logger.error(f"Failed to save to MongoDB: {e}")
            
            return render_template('flashcards.html', cards=cards, topic=topic, num_cards=num_cards)
            
        except Exception as e:
            logger.error(f"Error in flashcards route: {e}")
            flash('Error generating flashcards. Please try again.', 'error')
            return render_template('flashcards.html')
    
    # GET request - just show the form
    return render_template('flashcards.html')

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('index.html'), 500

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)