# test_api_simple.py
import requests
import os
from dotenv import load_dotenv
import json

load_dotenv()

token = os.getenv('HUGGINGFACE_API_KEY')
headers = {"Authorization": f"Bearer {token}"}

# Test with bart-large-cnn (summarization model)
url = "https://router.huggingface.co/hf-inference/models/facebook/bart-large-cnn"

# Test different types of prompts
test_cases = [
    ("summarization", "This is a long text about Python programming. Python is a popular programming language. It is used for web development, data science, and artificial intelligence. Many companies use Python for their applications."),
    ("generation", "Explain what is machine learning in simple terms."),
]

for test_type, text in test_cases:
    print(f"\n📌 Testing {test_type}...")
    
    payload = {
        "inputs": text,
        "parameters": {
            "max_length": 100,
            "min_length": 30
        }
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Response type: {type(result)}")
            print(f"Response preview: {str(result)[:200]}")
            
            # Check different response formats
            if isinstance(result, list) and len(result) > 0:
                if 'summary_text' in result[0]:
                    print(f"✅ Summary: {result[0]['summary_text'][:100]}")
                elif 'generated_text' in result[0]:
                    print(f"✅ Generated: {result[0]['generated_text'][:100]}")
                else:
                    print(f"✅ List result: {result[0]}")
            elif isinstance(result, dict):
                print(f"✅ Dict result: {result}")
        else:
            print(f"❌ Error: {response.text}")
            
    except Exception as e:
        print(f"❌ Exception: {e}")