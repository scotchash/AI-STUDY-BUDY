# diagnose.py
import requests
import os
from dotenv import load_dotenv

load_dotenv()

print("=" * 50)
print("DIAGNOSTIC CHECK")
print("=" * 50)

# Check token
token = os.getenv('HUGGINGFACE_API_KEY')
print(f"Token exists: {'✅' if token else '❌'}")
if token:
    print(f"Token starts with: {token[:10]}...")
    print(f"Token length: {len(token)}")

# Check internet connection
try:
    requests.get("https://www.google.com", timeout=5)
    print("Internet connection: ✅")
except:
    print("Internet connection: ❌")

# Test Hugging Face API
print("\nTesting Hugging Face API...")
url = "https://router.huggingface.co/hf-inference/models/facebook/bart-large-cnn"
headers = {"Authorization": f"Bearer {token}"}
payload = {"inputs": "Hello, this is a test."}

try:
    response = requests.post(url, headers=headers, json=payload, timeout=10)
    print(f"Status code: {response.status_code}")
    if response.status_code == 200:
        print("✅ API is working!")
        print(f"Response: {response.json()}")
    else:
        print(f"❌ API error: {response.text}")
except Exception as e:
    print(f"❌ Exception: {e}")

print("=" * 50)
