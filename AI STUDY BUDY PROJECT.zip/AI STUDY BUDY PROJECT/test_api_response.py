# test_api_response.py
import requests
import os
from dotenv import load_dotenv
import json

load_dotenv()

token = os.getenv('HUGGINGFACE_API_KEY')
headers = {"Authorization": f"Bearer {token}"}
url = "https://router.huggingface.co/hf-inference/models/facebook/bart-large-cnn"

print("=" * 60)
print("TESTING HUGGING FACE API RESPONSES")
print("=" * 60)

# Test 1: Simple explanation
print("\n📌 TEST 1: Explanation")
payload = {
    "inputs": "Explain Python programming in simple terms.",
    "parameters": {
        "max_length": 200,
        "min_length": 50
    }
}

response = requests.post(url, headers=headers, json=payload)
print(f"Status: {response.status_code}")
if response.status_code == 200:
    result = response.json()
    print(f"Response type: {type(result)}")
    print(f"Full response: {json.dumps(result, indent=2)[:500]}")
else:
    print(f"Error: {response.text}")

# Test 2: Summarization
print("\n📌 TEST 2: Summarization")
payload = {
    "inputs": "Python is a high-level programming language. It was created by Guido van Rossum and first released in 1991. Python has a design philosophy that emphasizes code readability, notably using significant whitespace. It provides constructs that enable clear programming on both small and large scales.",
    "parameters": {
        "max_length": 100,
        "min_length": 30
    }
}

response = requests.post(url, headers=headers, json=payload)
print(f"Status: {response.status_code}")
if response.status_code == 200:
    result = response.json()
    print(f"Response type: {type(result)}")
    print(f"Full response: {json.dumps(result, indent=2)[:500]}")